module NKF
  AUTO = 0
  JIS = 1
  EUC = 2
  SJIS = 3
  BINARY = 4
  NOCONV = 5
  ASCII = 6
  UTF8 = 8
  UTF16 = 16
  UTF32 = 32
  UNKNOWN = AUTO
end