package jfun.parsec;

/**
 * This class is an indicator of "no value". It is introduced to overcome the type problem in java 5 generics. 
 * <p>
 * @author Ben Yu
 * Apr 14, 2006 9:18:30 AM
 * @since version 1.0
 */
public class _ {}
