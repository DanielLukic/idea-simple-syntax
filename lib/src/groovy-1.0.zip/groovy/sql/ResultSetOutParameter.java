package groovy.sql;

/**
 * A ResultSet out parameter.
 * @author rfuller
 *
 */
public interface ResultSetOutParameter extends OutParameter{

}
