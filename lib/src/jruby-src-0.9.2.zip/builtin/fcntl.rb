class Fcntl
  F_SETFL = 1
  O_RDWR = File::RDWR
  O_TRUNC = File::TRUNC
  O_RDONLY = File::RDONLY
  O_EXCL = File::EXCL
  O_ACCMODE = File::NOCTTY
  O_NONBLOCK = File::NONBLOCK
  O_CREAT = File::CREAT
  O_WRONLY = File::WRONLY
  O_APPEND = File::APPEND
end
