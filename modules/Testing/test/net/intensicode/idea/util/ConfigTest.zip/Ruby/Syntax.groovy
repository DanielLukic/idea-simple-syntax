
package Ruby

import flux.FluxBuilder
import com.intellij.lexer.FlexAdapter

def syntax = new File( configFolder, 'Ruby/Syntax.flux' ).text
def code = new FluxBuilder( configFolder ).using( syntax ).create( "RubySyntaxFlexer" )
def clazz = evaluate( code )
def instance = clazz.newInstance( configuration )
return new FlexAdapter( instance )
