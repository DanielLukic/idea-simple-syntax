=begin
these things here are weird comments..
=end

# full line comments.. i like.. very nice
# how funny is that? :)
class Toast

   attr_reader :w00t # simple line comment

   def cheese( args )
       @mogg = args
       schlupp1 = 'rupp'
       schnuff2 = "hussle #{hummel}"
       that = 4.2
       thuz = 0xABcd
   end

   DONT_CHANGE = ILikeYouJustTheWayYouAre.new

   def huzzle( thiz, that )
       @@schmogg = @mogg + thiz * that
       %Q!rumsel #{pumsel} testerle!
       %Q{rumsel \#\{pumsel\} testerle}
   end

   # A check for regex..
   def get_current_method_name
       if /'(.*)'/.match(caller.first)
           return $1
       end
       nil
   end

end
