
package flux;

import JFlex.GroovyEmitter
import JFlex.JFlexer


class FluxBuilder
    {
    FluxBuilder( aBaseFolder )
        {
        myBaseFolder = aBaseFolder
        }

    def using( aSyntax )
        {
        mySyntax = aSyntax
        return this
        }

    def create( aClassName )
        {
        def header = new File( myBaseFolder, "FluxSyntax.header" ).getText()
        def skeleton = new File( myBaseFolder, "FluxSyntax.skeleton" ).getText()

        def syntax = merge( header, mySyntax ).replacing( "CLASSNAME": aClassName ).create()
        def flexer = new JFlexer( new GroovyEmitter() ).setSkeleton( skeleton )

        File.createTempFile( "FluxBuilder", "flex" ).write( syntax )
        
        def lexerCode = flexer.generate( new StringReader( syntax ) )
        return lexerCode + "\nreturn " + aClassName + ".class\n"
        }

    private merge( aHeader, aSyntax )
        {
        def syntax = aHeader + aSyntax;
        return new TagReplacer( syntax )
        }

    private def mySyntax
    private def myBaseFolder
    }
